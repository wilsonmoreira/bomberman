package rubik;

import rubik.grafico.JFrameRubik;

public class MainGrafico {

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

                                    public void run() {
                                        new JFrameRubik().setVisible(true);
                                    }
                                });
    }
}
