/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rubik;

import java.util.Vector;
import rubik.busqueda.BusquedaAnchura;
import rubik.modelo.EstadoRubik;
import rubik.modelo.OperadorRubik;
import rubik.busqueda.Operador;
import rubik.busqueda.Problema;
import rubik.modelo.Cubo;
import rubik.modelo.Movimiento;

/**
 *
 * @author rp
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        Cubo cubo = new Cubo();
        Vector<Movimiento> movsMezcla = cubo.mezclar(4);

        System.out.println("MOVIMIENTOS:");
        for (Movimiento m : movsMezcla) {
            System.out.print(m.toString() + " ");
        }
        System.out.println();

        System.out.println("CUBO INICIAL:\n" + cubo.toString());

        Problema problema = new Problema(new EstadoRubik(cubo), new BusquedaAnchura());

        System.out.println("SOLUCION:");
        Vector<Operador> opsSolucion = problema.obtenerSolucion();
        if (opsSolucion != null) {
            for (Operador o : opsSolucion) {
                System.out.println(o.getEtiqueta() + " ");
                OperadorRubik or = (OperadorRubik) o;
                cubo.mover(or.getMovimiento());
            }
            System.out.println();

            System.out.println("CUBO FINAL:\n" + cubo.toString());

        } else {
            System.out.println("no se ha encontrado solución");
        }

    }
}
