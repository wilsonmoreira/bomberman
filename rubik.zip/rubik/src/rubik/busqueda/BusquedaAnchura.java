/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rubik.busqueda;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Vector;

/**
 * Implementa una búsqueda en Anchura genérica (independiente de Estados y Operadores)
 * controlando repetición de estados.
 * Usa lista ABIERTOS (LinkedList) y lista CERRADOS (Hastable usando Estado como clave)
 * @author rp
 */
public class BusquedaAnchura implements Busqueda {

    /** Lista ABIERTOS implementada como una lista enlazada de NodoAnchura */
    private LinkedList<NodoAnchura> abiertos;
    
    //private HashSet<Estado> cerrados;
    /** Lista CERRADOS implementada como una tabla hash donde las claves son
     *  objetos de tipo Estado
     */
    private HashMap<Estado, NodoAnchura> cerrados;

    /** Constructor de una búsqueda en anchura, crear las listas ABIERTOS y CERRADOS*/
    public BusquedaAnchura() {
        abiertos = new LinkedList<NodoAnchura>(); // Acceso orfenado (PILA)
        cerrados = new HashMap<Estado, NodoAnchura>(); // Acceso directo (por Estado)
    }

    /** 
     * Implementa la búsqueda en anchura. Si encuentra solución recupera la lista
     * de Operadores empleados almacenada en los atributos de los objetos NodoAnchura
     * @param inicial Estado inicial de la búsqueda
     * @return null o Vector con la lista de Operadores que llevan a la solución
     */
    public Vector<Operador> buscarSolucion(Estado inicial) {
        NodoAnchura nodoActual = null;
        Estado actual, hijo;
        boolean solucion = false;

        abiertos.clear();
        cerrados.clear();
        abiertos.add(new NodoAnchura(inicial, null, null));
        while (!solucion && !abiertos.isEmpty()) {
            nodoActual = abiertos.poll();
            actual = nodoActual.getEstado();
            
            if (actual.esFinal()) {
                solucion = true;
            } else {
                cerrados.put(actual, nodoActual);             

                for (Operador operador : actual.operadoresAplicables()) {
                    hijo = actual.aplicarOperador(operador);
                    if (!cerrados.containsKey(hijo)) {
                        abiertos.addLast(new NodoAnchura(hijo, nodoActual, operador));
                    }
                }
            }
        }
        
        if (solucion) {
            Vector<Operador> lista = new Vector<Operador>();
            NodoAnchura nodo = nodoActual;

            while (nodo.getPadre() != null) { // Asciende hasta raíz
                lista.insertElementAt(nodo.getOperador(), 0);
                nodo = (NodoAnchura) nodo.getPadre();
            }
            return (lista);
        } else {
            return ((Vector<Operador>) null);
        }
    }
}
