/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package rubik.modelo;

import rubik.busqueda.Operador;

/**
 * Implementa el interfaz Operador encapsulando un movimiento (giro) Rubik
 * @author ribadas
 */
public class OperadorRubik implements Operador {
    /** Movimiento asociado al operador */
    private Movimiento movimiento;

    public OperadorRubik(Movimiento movimiento) {
        this.movimiento = movimiento;
    }

    public Movimiento getMovimiento() {
        return movimiento;
    }

    public void setMovimiento(Movimiento movimiento) {
        this.movimiento = movimiento;
    }

    public String getEtiqueta() {
        return (movimiento.toString());
    }


    /** El coste de los giros es siempre 1 (para la búsqueda todos son idénticos)*/
    public double getCoste() {
        return (1);
    }
}
