/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rubik.modelo;

import rubik.busqueda.Estado;
import rubik.busqueda.Operador;
import java.util.Vector;

/**
 * Objeto que implementa la interfaz Estado para un cubo Rubik concreto.
 * La mayor parte de los métodos definidos en el interfaz Estado se 
 * delegan en el objeto Cubo
 * @author rp
 */
public class EstadoRubik implements Estado {
    /** Vector estático con la lista de los 12 OperadoresRubik posibles */
    private static final Vector<Operador> listaOperadoresAplicables =
            EstadoRubik.inicializarListaOperadoresAplicables();

    /** Metodo estático para inicializar el vector estático de operadores aplicables*/
    private static Vector<Operador> inicializarListaOperadoresAplicables() {
        Vector<Operador> lista = new Vector<Operador>(Movimiento.movimientosPosibles.length);
        for (Movimiento m : Movimiento.movimientosPosibles) {
            lista.add(new OperadorRubik(m));
        }
        return (lista);
    }
    
    /** Objeto Cubo correspondiente a este estado */
    private Cubo cubo;

    public EstadoRubik(Cubo cubo) {
        this.cubo = cubo;
    }

    public Cubo getCubo() {
        return cubo;
    }

    public void setCubo(Cubo cubo) {
        this.cubo = cubo;
    }

    /** Todos los giros del cubo rubik son siempre aplicables */
    public Vector<Operador> operadoresAplicables() {
        return (EstadoRubik.listaOperadoresAplicables);
    }

    /** Comprueba si el cubo actual está solucionado */
    public boolean esFinal() {
        return (cubo.esConfiguracionFinal());
    }

    /** Aplica sobre el Cubo el movimiento asciado al operador */
    public Estado aplicarOperador(OperadorRubik o) {
        Cubo nuevo = this.cubo.clone();
        nuevo.mover(o.getMovimiento());
        return (new EstadoRubik(nuevo));
    }


    /** Delega el calculo del Hash en el cubo */
    @Override
    public int hashCode() {
        return (cubo.hashCode());
    }

    /** Extrae un objeti EstadoRubik del parámetro recibido y delega la comparación
     *  en el método equals() del Cubo interno (lo compara con el cubo recibido)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if ((o == null) || (this.getClass() != o.getClass())) {
            return false;
        }
        EstadoRubik e = (EstadoRubik) o;        
        return (cubo.equals(e.getCubo()));
    }

    @Override
    public String toString() {
        return (cubo.toString());
    }
    
    public Estado aplicarOperador(Operador o) {
        return(aplicarOperador((OperadorRubik) o));
    }

    
}
